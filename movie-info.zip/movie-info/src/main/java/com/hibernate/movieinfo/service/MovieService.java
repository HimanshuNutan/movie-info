package com.hibernate.movieinfo.service;

import com.hibernate.movieinfo.dao.MovieDAO;
import com.hibernate.movieinfo.models.MovieInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MovieService {
  @Autowired
  MovieDAO movieDAO;

  public MovieInfo getMovie(String movieId) {
    movieDAO.setup();
    MovieInfo movie = movieDAO.getMovie(movieId);
    movieDAO.exit();
    return movie;
  }

  public List<MovieInfo> getAllMovies() {
    movieDAO.setup();
    List<MovieInfo> list = movieDAO.getAllMovies();
    movieDAO.exit();
    return list;
  }

  public void addMovie(MovieInfo movie) {
    movieDAO.setup();
    movieDAO.addMovie(movie);
    movieDAO.exit();
  }

  public void updateMovie(MovieInfo movie) {
    movieDAO.setup();
    movieDAO.updateMovie(movie);
    movieDAO.exit();
  }

  public void deleteMovie(String movieID) {
    movieDAO.setup();
    movieDAO.deleteMovie(movieID);
    movieDAO.exit();
  }
}
