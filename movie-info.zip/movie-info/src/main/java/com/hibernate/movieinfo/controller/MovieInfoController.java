package com.hibernate.movieinfo.controller;


import com.hibernate.movieinfo.models.MovieInfo;
import com.hibernate.movieinfo.service.MovieService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/movies")
public class MovieInfoController {
	private static final Logger logger = LogManager.getLogger();
//	  @Autowired
//	     private RestTemplate restTemplate;

//		 @RequestMapping("/{movieId}")
//		    public MovieInfoDO getMovieInfo(@PathVariable("movieId") String movieId) {
//			 MovieDAO movieDao = new MovieDAO();
//			 List<MovieInfoDO> movieList = movieDao.getMovieList();
//			 Optional<MovieInfoDO> movie = movieList.stream().filter((m -> m.getMovieId().equals(movieId))).findFirst();
//			 return movie.get();
//		    }
		@Autowired
		private MovieService movieService;
		@PostMapping(value = "/movie")
		public void addMovie(@RequestBody MovieInfo movie){
			try{
				movieService.addMovie(movie);
				logger.info("movie added"+movie);
			}catch (Exception e){
				logger.error(e);
			}
		}

		@GetMapping(value = "/movie/{movieId}")
		public MovieInfo getMovie(@PathVariable("movieId") String movieId){
			MovieInfo movie = new MovieInfo();
			try{
				movie = movieService.getMovie(movieId);
				System.out.println(movie+"   "+movieId);
			}catch (Exception e){
				logger.error(e);
				System.out.println(e);
			}
			return movie;
		}

		@DeleteMapping(value = "/movie/{movieId}")
		public void deleteMovie(@PathVariable("movieId") String movieId){
			try{
				movieService.deleteMovie(movieId);
			}catch (Exception e){
				logger.error(e);
			}
		}

		@PutMapping(value = "/movie")
		public void updateMovie(@RequestBody MovieInfo movie){
			try{
				movieService.updateMovie(movie);
			}catch (Exception e){
				logger.error(e);
			}
		}

		@GetMapping(value = "/list-movies")
		public List<MovieInfo> getAllMovies(){
			List<MovieInfo> list = new ArrayList<>();
			try{
				list = movieService.getAllMovies();
			}catch (Exception e){
				logger.error(e);
			}
			return list;
		}

}