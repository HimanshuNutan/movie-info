package com.hibernate.movieinfo.dao;

import com.hibernate.movieinfo.models.MovieInfo;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;


@Repository
public class MovieDAO {

  private List<MovieInfo> movieList = new ArrayList<>();
  protected SessionFactory sessionFactory;
  private static final Logger logger = LogManager.getLogger();

//  public MovieDAO() {
//    movieList.add(new MovieInfoDO("123", "Transformer", "Action"));
//    movieList.add(new MovieInfoDO("124", "Titanic", "Disaster"));
//    movieList.add(new MovieInfoDO("125", "BigSick", "Romance"));
//    movieList.add(new MovieInfoDO("126", "Adrift", "Sad"));
//  }

//  public List<MovieInfoDO> getMovieList() {
//    return movieList;
//  }

//  public void setMovieList(List<MovieInfoDO> movieList) {
//    this.movieList = movieList;
//  }

  public void setup() {
    final StandardServiceRegistry registry = new StandardServiceRegistryBuilder()
            .configure()
            .build();
    try {
      sessionFactory = new MetadataSources(registry).buildMetadata().buildSessionFactory();
    } catch (Exception e) {
      logger.error(e);
      StandardServiceRegistryBuilder.destroy(registry);
    }
  }

  public void exit() {
    sessionFactory.close();
  }

  public List<MovieInfo> getAllMovies() {
    Session session = sessionFactory.openSession();
    return session.createQuery("from MovieInfo").getResultList();
  }

  public MovieInfo getMovie(String movieId) {
    MovieInfo movie = new MovieInfo();
    Session session = sessionFactory.openSession();
    try {
      movie = session.get(MovieInfo.class, movieId);
      logger.info(movie);
    } catch (Exception e) {
      logger.error(e);
    }
    return movie;
  }

  public void addMovie(MovieInfo movie) {
    Session session = sessionFactory.openSession();
    try {
      session.beginTransaction();
      session.save(movie);
      session.getTransaction().commit();
    } catch (Exception e) {
      logger.error(e);
    }

  }

  public void updateMovie(MovieInfo movie) {
    Session session = sessionFactory.openSession();
    try {
      session.beginTransaction();
      session.update(movie);
      session.getTransaction().commit();
    } catch (Exception e) {
      logger.error(e);
    }

  }

  public void deleteMovie(String movieId) {
    Session session = sessionFactory.openSession();
    try {
      session.beginTransaction();
      session.delete(getMovie(movieId));
      session.getTransaction().commit();
    } catch (Exception e) {
      logger.error(e);
    }

  }

}
