package com.hibernate.movieinfo.models;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "movieinfo")
public class MovieInfo {
  @Column(name = "movieid")
  @Id
  @Getter
  @Setter
  private String movieId;
  @Column(name = "name")
  @Getter
  @Setter
  private String name;
  @Column(name = "description")
  @Getter
  @Setter
  private String description;

  public MovieInfo() {
  }
  public MovieInfo(String movieId, String name, String description) {
    this.movieId = movieId;
    this.name = name;
    this.description = description;
  }

}