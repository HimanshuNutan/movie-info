DROP TABLE IF EXISTS movieinfo;

CREATE TABLE movieinfo(
movieid varchar(10),
name varchar(30),
description varchar(100));

INSERT INTO movieinfo
(movieid,name,description)
VALUES('1','Ironman','Hero, Billionaire, PlayBoy, Philanthropist');

INSERT INTO movieinfo
(movieid,name,description)
VALUES('2','Avatar','Jake Sulley - from human to alien');